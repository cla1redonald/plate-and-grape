describe('PlateAndGrape', () => {
  it('should pass a basic test', () => {
    expect(true).toBe(true);
  });
});
